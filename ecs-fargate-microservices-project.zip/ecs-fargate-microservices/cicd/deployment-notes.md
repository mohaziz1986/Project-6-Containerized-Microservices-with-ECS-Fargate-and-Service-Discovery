# CI/CD and Blue/Green Deployment Notes

## Build pipeline

1. Source action checks out the repository.
2. CodeBuild runs tests and builds the three Docker images.
3. Images are tagged with the immutable Git commit SHA and pushed to ECR.
4. A deployment stage updates the ECS service task definition.

## CodeDeploy ECS blue/green

For each service, CodeDeploy requires:
- ECS service deployment controller set to `CODE_DEPLOY`.
- An ECS CodeDeploy application and deployment group.
- A production listener and optional test listener.
- A target-group pair for the service.
- A CodeDeploy service role with permissions to create task sets and modify ELB routing.
- An AppSpec file referencing the new task definition and container name/port.

**Do not attach three independent CodeDeploy deployment groups to one shared ALB listener and assume they can each swap only their own path rule.** CodeDeploy's ECS traffic control is listener-based. Use a separately controllable routing topology per service, or use ECS-native blue/green deployment with the production listener-rule ARN for each path rule. Validate the exact CDK/AWS API behavior in a disposable account before enabling production traffic shifting.

## Recommended pipeline separation

A practical release setup has one pipeline per microservice, with shared source and reusable build logic. Each pipeline builds only its service, pushes an immutable image tag, registers a new task definition, and deploys only that service. Add manual approval before production traffic shift and CloudWatch alarms for error rate, latency, and unhealthy targets.
