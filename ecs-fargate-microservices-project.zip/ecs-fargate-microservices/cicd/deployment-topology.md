# Deployment topology decision record

## Requirement
Three independently deployable Fargate services behind one ALB listener with path rules, plus CodeDeploy blue/green deployment.

## Finding
The CodeDeploy ECS deployment model is configured around a production listener (and optional test listener) plus a target-group pair for an ECS service. The shared-ALB design has three separate listener rules. A CodeDeploy deployment group configured with the listener ARN must not be assumed to manage only one of those path rules. This is a routing-control mismatch.

## Baseline in this repository
- One ALB listener with three path rules.
- Three ECS services using ECS rolling deployment controller.
- Independent ECR repositories and task definitions.
- Buildspec/AppSpec examples and the CodeDeploy design notes remain as learning artifacts.

## Supported next-step choices
1. Preserve the shared ALB and use ECS rolling deployments (current baseline).
2. Preserve the shared ALB and evaluate ECS-native blue/green, configuring a distinct production listener-rule ARN and target-group pair per service.
3. Keep CodeDeploy ECS blue/green but redesign routing so each service has a dedicated production/test listener route and target-group pair. Confirm that the selected topology is supported by the current CodeDeploy API and CDK version before production use.

## Acceptance tests
- Deploy Auth and verify `/api/auth/health`.
- Deploy Orders and verify `/api/orders/health`.
- Deploy Notifications and verify `/api/notifications/health`.
- Deploy one service and confirm the other two listener rules and target groups are unchanged.
- Roll back one service and confirm only its traffic is reverted.
