import * as cdk from 'aws-cdk-lib';
import { Construct } from 'constructs';
import * as ec2 from 'aws-cdk-lib/aws-ec2';
import * as ecs from 'aws-cdk-lib/aws-ecs';
import * as ecr from 'aws-cdk-lib/aws-ecr';
import * as elbv2 from 'aws-cdk-lib/aws-elasticloadbalancingv2';
import * as servicediscovery from 'aws-cdk-lib/aws-servicediscovery';
import * as secretsmanager from 'aws-cdk-lib/aws-secretsmanager';
import * as elasticache from 'aws-cdk-lib/aws-elasticache';
import * as iam from 'aws-cdk-lib/aws-iam';
import * as logs from 'aws-cdk-lib/aws-logs';

interface MicroservicesStackProps extends cdk.StackProps {
  projectName: string;
  allowedCidr: string;
  imageTag: string;
}

export class MicroservicesStack extends cdk.Stack {
  constructor(scope: Construct, id: string, props: MicroservicesStackProps) {
    super(scope, id, props);
    const name = props.projectName;

    const vpc = new ec2.Vpc(this, 'Vpc', {
      vpcName: `${name}-vpc`,
      maxAzs: 2,
      natGateways: 1,
      subnetConfiguration: [
        { name: 'public', subnetType: ec2.SubnetType.PUBLIC, cidrMask: 24 },
        { name: 'private', subnetType: ec2.SubnetType.PRIVATE_WITH_EGRESS, cidrMask: 24 },
      ],
    });

    const albSg = new ec2.SecurityGroup(this, 'AlbSecurityGroup', {
      vpc, description: 'Public entry to the application load balancer', allowAllOutbound: true,
    });
    albSg.addIngressRule(ec2.Peer.ipv4(props.allowedCidr), ec2.Port.tcp(80), 'HTTP from approved CIDR');

    const taskSg = new ec2.SecurityGroup(this, 'TaskSecurityGroup', {
      vpc, description: 'Application tasks accept traffic from ALB and peer tasks', allowAllOutbound: true,
    });
    taskSg.addIngressRule(albSg, ec2.Port.tcp(3000), 'ALB to application containers');
    taskSg.addIngressRule(taskSg, ec2.Port.tcp(3000), 'Service-to-service calls');

    const redisSg = new ec2.SecurityGroup(this, 'RedisSecurityGroup', {
      vpc, description: 'Redis access only from application tasks', allowAllOutbound: false,
    });
    redisSg.addIngressRule(taskSg, ec2.Port.tcp(6379), 'Application tasks to Redis');

    const cluster = new ecs.Cluster(this, 'Cluster', {
      vpc, clusterName: `${name}-cluster`, containerInsights: true,
    });

    const namespace = new servicediscovery.PrivateDnsNamespace(this, 'Namespace', {
      name: 'service.local', vpc, description: 'Private namespace for microservice discovery',
    });

    const authSecret = secretsmanager.Secret.fromSecretNameV2(this, 'AuthSecret', 'microservices/auth');
    const ordersSecret = secretsmanager.Secret.fromSecretNameV2(this, 'OrdersSecret', 'microservices/orders');
    const notificationsSecret = secretsmanager.Secret.fromSecretNameV2(this, 'NotificationsSecret', 'microservices/notifications');

    const redisAuth = new secretsmanager.Secret(this, 'RedisAuthToken', {
      secretName: `${name}/redis-auth`,
      generateSecretString: {
        passwordLength: 32, excludePunctuation: true, includeSpace: false,
      },
    });

    const redisSubnetGroup = new elasticache.CfnSubnetGroup(this, 'RedisSubnetGroup', {
      description: 'Private subnet group for Redis',
      subnetIds: vpc.privateSubnets.map(s => s.subnetId),
      cacheSubnetGroupName: `${name}-redis-subnets`,
    });

    const redis = new elasticache.CfnReplicationGroup(this, 'Redis', {
      replicationGroupDescription: 'Shared session cache for ECS microservices',
      replicationGroupId: `${name}-redis`,
      engine: 'redis',
      cacheNodeType: 'cache.t4g.micro',
      numCacheClusters: 1,
      automaticFailoverEnabled: false,
      multiAzEnabled: false,
      cacheSubnetGroupName: redisSubnetGroup.ref,
      securityGroupIds: [redisSg.securityGroupId],
      transitEncryptionEnabled: true,
      atRestEncryptionEnabled: true,
      authToken: redisAuth.secretValue.unsafeUnwrap(),
      port: 6379,
    });
    redis.addDependency(redisSubnetGroup);

    const alb = new elbv2.ApplicationLoadBalancer(this, 'Alb', {
      vpc, internetFacing: true, securityGroup: albSg,
      loadBalancerName: `${name}-alb`,
      vpcSubnets: { subnetType: ec2.SubnetType.PUBLIC },
    });
    const listener = alb.addListener('HttpListener', {
      port: 80, open: false,
      defaultAction: elbv2.ListenerAction.fixedResponse(404, {
        contentType: 'application/json', messageBody: '{"error":"not_found"}',
      }),
    });

    const services = [
      { id: 'Auth', path: '/api/auth/*', repo: 'auth', secret: authSecret, secretKey: 'JWT_SECRET', envKey: 'JWT_SECRET', discovery: 'auth', health: '/api/auth/health' },
      { id: 'Orders', path: '/api/orders/*', repo: 'orders', secret: ordersSecret, secretKey: 'DATABASE_URL', envKey: 'DATABASE_URL', discovery: 'orders', health: '/api/orders/health' },
      { id: 'Notifications', path: '/api/notifications/*', repo: 'notifications', secret: notificationsSecret, secretKey: 'NOTIFICATION_API_KEY', envKey: 'NOTIFICATION_API_KEY', discovery: 'notifications', health: '/api/notifications/health' },
    ];

    const ecrRepos: Record<string, ecr.Repository> = {};
    for (const svc of services) {
      ecrRepos[svc.repo] = new ecr.Repository(this, `${svc.id}Repository`, {
        repositoryName: `${name}/${svc.repo}`,
        imageScanOnPush: true,
        imageTagMutability: ecr.TagMutability.IMMUTABLE,
        removalPolicy: cdk.RemovalPolicy.DESTROY,
        emptyOnDelete: true,
      });
    }

    for (let i = 0; i < services.length; i++) {
      const svc = services[i];
      const executionRole = new iam.Role(this, `${svc.id}ExecutionRole`, {
        assumedBy: new iam.ServicePrincipal('ecs-tasks.amazonaws.com'),
        description: `ECS execution role for ${svc.id}`,
      });
      executionRole.addManagedPolicy(iam.ManagedPolicy.fromAwsManagedPolicyName(
        'service-role/AmazonECSTaskExecutionRolePolicy',
      ));
      svc.secret.grantRead(executionRole);
      redisAuth.grantRead(executionRole);

      const taskRole = new iam.Role(this, `${svc.id}TaskRole`, {
        assumedBy: new iam.ServicePrincipal('ecs-tasks.amazonaws.com'),
        description: `Application task role for ${svc.id}`,
      });
      taskRole.addToPolicy(new iam.PolicyStatement({
        actions: ['xray:PutTraceSegments', 'xray:PutTelemetryRecords'],
        resources: ['*'],
      }));

      const taskDef = new ecs.FargateTaskDefinition(this, `${svc.id}TaskDefinition`, {
        family: `${name}-${svc.repo}`,
        cpu: 256, memoryLimitMiB: 512,
        executionRole, taskRole,
      });
      const logGroup = new logs.LogGroup(this, `${svc.id}Logs`, {
        logGroupName: `/ecs/${name}/${svc.repo}`,
        retention: logs.RetentionDays.ONE_WEEK,
        removalPolicy: cdk.RemovalPolicy.DESTROY,
      });

      const container = taskDef.addContainer(`${svc.id}Container`, {
        containerName: svc.repo,
        image: ecs.ContainerImage.fromEcrRepository(ecrRepos[svc.repo], props.imageTag),
        logging: ecs.LogDrivers.awsLogs({ logGroup, streamPrefix: svc.repo }),
        environment: {
          PORT: '3000',
          SERVICE_NAME: svc.repo,
          REDIS_HOST: redis.attrPrimaryEndPointAddress,
          REDIS_PORT: '6379',
          REDIS_TLS: 'true',
          AUTH_SERVICE_URL: 'http://auth.service.local:3000',
          NOTIFICATIONS_SERVICE_URL: 'http://notifications.service.local:3000',
          AWS_XRAY_TRACING_NAME: `${name}-${svc.repo}`,
        },
        secrets: {
          [svc.envKey]: ecs.Secret.fromSecretsManager(svc.secret, svc.secretKey),
          REDIS_AUTH_TOKEN: ecs.Secret.fromSecretsManager(redisAuth),
        },
        healthCheck: {
          command: ['CMD-SHELL', 'node -e "require(\\'http\\').get(\\'http://127.0.0.1:3000/health\\',r=>process.exit(r.statusCode===200?0:1)).on(\\'error\\',()=>process.exit(1))"'],
          interval: cdk.Duration.seconds(30), timeout: cdk.Duration.seconds(5),
          retries: 3, startPeriod: cdk.Duration.seconds(20),
        },
      });
      container.addPortMappings({ containerPort: 3000, protocol: ecs.Protocol.TCP });
      container.addEnvironment('AWS_XRAY_DAEMON_ADDRESS', '127.0.0.1:2000');
      const xray = taskDef.addContainer(`${svc.id}XRayDaemon`, {
        image: ecs.ContainerImage.fromRegistry('public.ecr.aws/xray/aws-xray-daemon:3.x'),
        memoryLimitMiB: 64,
        essential: false,
        command: ['--local-mode'],
        logging: ecs.LogDrivers.awsLogs({ logGroup, streamPrefix: 'xray-daemon' }),
      });
      xray.addPortMappings({ containerPort: 2000, protocol: ecs.Protocol.UDP });

      const service = new ecs.FargateService(this, `${svc.id}Service`, {
        cluster, serviceName: `${name}-${svc.repo}`,
        taskDefinition: taskDef,
        desiredCount: 1,
        assignPublicIp: false,
        securityGroups: [taskSg],
        vpcSubnets: { subnetType: ec2.SubnetType.PRIVATE_WITH_EGRESS },
        cloudMapOptions: {
          name: svc.discovery,
          cloudMapNamespace: namespace,
          dnsRecordType: servicediscovery.DnsRecordType.A,
          dnsTtl: cdk.Duration.seconds(10),
          container, containerPort: 3000,
        },
        minHealthyPercent: 100,
        maxHealthyPercent: 200,
      });

      const target = new elbv2.ApplicationTargetGroup(this, `${svc.id}TargetGroup`, {
        vpc, targetGroupName: `${name}-${svc.repo}`.slice(0, 32),
        port: 3000, protocol: elbv2.ApplicationProtocol.HTTP,
        targetType: elbv2.TargetType.IP,
        healthCheck: { path: '/health', healthyHttpCodes: '200' },
      });
      target.addTarget(service);
      listener.addTargetGroups(`${svc.id}PathRule`, {
        priority: 10 + i * 10,
        conditions: [elbv2.ListenerCondition.pathPatterns([svc.path])],
        targetGroups: [target],
      });
      service.autoScaleTaskCount({ minCapacity: 1, maxCapacity: 4 })
        .scaleOnCpuUtilization(`${svc.id}CpuScaling`, { targetUtilizationPercent: 60 });
    }

    new cdk.CfnOutput(this, 'LoadBalancerDnsName', { value: alb.loadBalancerDnsName });
    new cdk.CfnOutput(this, 'VpcId', { value: vpc.vpcId });
    new cdk.CfnOutput(this, 'ClusterName', { value: cluster.clusterName });
    for (const [key, repo] of Object.entries(ecrRepos)) {
      new cdk.CfnOutput(this, `${key}RepositoryUri`, { value: repo.repositoryUri });
    }
    new cdk.CfnOutput(this, 'RedisEndpoint', { value: redis.attrPrimaryEndPointAddress });
  }
}
