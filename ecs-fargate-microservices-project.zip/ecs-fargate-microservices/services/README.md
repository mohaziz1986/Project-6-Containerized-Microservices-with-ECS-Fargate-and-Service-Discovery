# Microservices

Each directory contains an independently packaged Node.js service and Dockerfile.

- `auth`: demo session creation and lookup backed by Redis.
- `orders`: demo order endpoint with optional session validation against Redis.
- `notifications`: demo notification acceptance endpoint.

All services expose `/health` for container and ALB health checks. In production, add authentication/authorization, request validation, rate limiting, durable persistence, idempotency, and integration tests.
