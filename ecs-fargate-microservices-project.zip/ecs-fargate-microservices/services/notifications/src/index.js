const express = require('express');
const AWSXRay = require('aws-xray-sdk');
const app = express();
app.use(express.json());
app.use(AWSXRay.express.openSegment('notifications-service'));
app.get('/health', (_req,res)=>res.json({service:'notifications',status:'ok'}));
app.get('/api/notifications/health', (_req,res)=>res.json({service:'notifications',status:'ok'}));
app.post('/api/notifications', (req,res)=>res.status(202).json({
  accepted:true,notificationId:require('crypto').randomUUID(),channel:req.body.channel || 'email'
}));
app.listen(process.env.PORT || 3000,'0.0.0.0',()=>console.log(JSON.stringify({service:'notifications',event:'started'})));
