const express = require('express');
const AWSXRay = require('aws-xray-sdk');
const { createClient } = require('redis');
const app = express();
app.use(express.json());
AWSXRay.captureHTTPsGlobal(require('http'));
AWSXRay.captureHTTPsGlobal(require('https'));
app.use(AWSXRay.express.openSegment('auth-service'));

let redis;
async function getRedis() {
  if (redis) return redis;
  redis = createClient({
    url: `rediss://${process.env.REDIS_HOST}:${process.env.REDIS_PORT || 6379}`,
    password: process.env.REDIS_AUTH_TOKEN,
    socket: { tls: true, rejectUnauthorized: true }
  });
  redis.on('error', err => console.error(JSON.stringify({level:'error',message:'redis_error',error:err.message})));
  await redis.connect();
  return redis;
}
app.get('/health', (_req,res) => res.json({service:'auth',status:'ok'}));
app.get('/api/auth/health', (_req,res) => res.json({service:'auth',status:'ok'}));
app.post('/api/auth/session', async (req,res) => {
  const sid = req.body.sessionId || require('crypto').randomUUID();
  const r = await getRedis();
  await r.set(`session:${sid}`, JSON.stringify({userId:req.body.userId || 'demo-user'}), {EX:3600});
  res.status(201).json({sessionId:sid,expiresIn:3600});
});
app.get('/api/auth/session/:id', async (req,res) => {
  const value = await (await getRedis()).get(`session:${req.params.id}`);
  if (!value) return res.status(404).json({error:'session_not_found'});
  res.json(JSON.parse(value));
});
app.use(AWSXRay.express.closeSegment());
app.listen(process.env.PORT || 3000, '0.0.0.0', () => console.log(JSON.stringify({service:'auth',event:'started'})));
