const express = require('express');
const AWSXRay = require('aws-xray-sdk');
const http = require('http');
const https = require('https');
const { createClient } = require('redis');
const app = express();
app.use(express.json());
AWSXRay.captureHTTPsGlobal(http);
AWSXRay.captureHTTPsGlobal(https);
app.use(AWSXRay.express.openSegment('orders-service'));
let redis;
async function getRedis() {
  if (redis) return redis;
  redis = createClient({url:`rediss://${process.env.REDIS_HOST}:${process.env.REDIS_PORT || 6379}`,
    password:process.env.REDIS_AUTH_TOKEN,socket:{tls:true,rejectUnauthorized:true}});
  redis.on('error', e => console.error(JSON.stringify({event:'redis_error',error:e.message})));
  await redis.connect(); return redis;
}
app.get('/health', (_req,res)=>res.json({service:'orders',status:'ok'}));
app.get('/api/orders/health', (_req,res)=>res.json({service:'orders',status:'ok'}));
app.post('/api/orders', async (req,res) => {
  const sessionId = req.header('x-session-id');
  if (sessionId) {
    const authBase = process.env.AUTH_SERVICE_URL || 'http://auth.service.local:3000';
    const url = new URL(`/api/auth/session/${encodeURIComponent(sessionId)}`, authBase);
    const transport = url.protocol === 'https:' ? https : http;
    const valid = await new Promise((resolve, reject) => {
      const request = transport.get(url, response => {
        response.resume();
        resolve(response.statusCode === 200);
      });
      request.setTimeout(3000, () => request.destroy(new Error('auth_timeout')));
      request.on('error', reject);
    }).catch(() => false);
    if (!valid) return res.status(401).json({error:'invalid_session'});
  }
  const order = {id:require('crypto').randomUUID(),items:req.body.items || [],status:'ACCEPTED'};
  res.status(201).json(order);
});
app.listen(process.env.PORT || 3000,'0.0.0.0',()=>console.log(JSON.stringify({service:'orders',event:'started'})));
