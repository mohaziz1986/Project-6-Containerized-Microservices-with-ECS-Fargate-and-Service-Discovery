import { App } from 'aws-cdk-lib';
import { MicroservicesStack } from '../lib/microservices-stack';

test('creates an ECS cluster and three ECR repositories', () => {
  const app = new App();
  const stack = new MicroservicesStack(app, 'TestStack', {
    projectName: 'test-microservices',
    allowedCidr: '203.0.113.10/32',
  });
  expect(stack).toBeDefined();
});
